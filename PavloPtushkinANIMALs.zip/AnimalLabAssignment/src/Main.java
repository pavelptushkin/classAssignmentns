public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog("dog");
        dog.getAnimalInfo();
        dog.speak();
        dog.eat();
        dog.moves();
    }
}
