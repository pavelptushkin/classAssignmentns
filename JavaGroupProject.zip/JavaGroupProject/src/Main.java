public class Main {
    public static void main (String[] args){
        AsciiChars.printUpperCase(AsciiChars.printLowerCase(AsciiChars.printNumbersAndLetters()));
        AsciiChars.askQuestions(AsciiChars.askName());
    }
}
